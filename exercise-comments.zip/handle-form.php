<?php

require_once 'lib/DBBlackbox.php';

// your code here
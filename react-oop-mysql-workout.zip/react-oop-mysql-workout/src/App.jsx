import { List } from './List/List'

function App() {
  return (
    <List url="" />
  )
}

export default App

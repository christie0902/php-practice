import React from 'react';

export const Game = (props) => {
    return (
        <div className="game">

        </div>
    );
}
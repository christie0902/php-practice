<?php

require_once "DB.php";

class City
{
    public function insert()
    {
        echo "<h3>Trying to build the city, but can't. Change me to save the new city into the database!</h3>";
    }
}